# CoordOverride — Minecraft 26.1.2 Fabric Mod

Replaces the **F3 debug screen coordinate line** with your choice of display mode, switchable at any time with a configurable keybind.

## Features

| Mode | What you see in F3 |
|---|---|
| **Real XYZ** | Vanilla default (exact floating-point position) |
| **Block XYZ** | Integer block position only |
| **Chunk Coords** | Chunk [X, Z] + local position within chunk |
| **Custom Coords** | Whatever X/Y/Z values you type in |
| **Hidden** | XYZ line is removed from F3 entirely |

## Usage

1. Press **G** (default) in-game to open the **Coord Picker** screen.
2. Click a mode to select it (highlighted in green).
3. If you pick **Custom Coords**, fill in the X/Y/Z fields.
4. Click **Save** — change takes effect immediately, no reload needed.

### Changing the keybind
Go to **Options → Controls → CoordOverride** and rebind `Open Coord Picker`.

## Building

> Requires: Java 21, internet access for Gradle downloads

```bash
./gradlew build
```

The `.jar` will be at `build/libs/coordoverride-<version>.jar`.

Or just push to GitHub — the Actions workflow builds it automatically and uploads the artifact.

## Updating `gradle.properties`

If the Fabric/Yarn versions listed don't match 26.1.2, update them from:
- **Yarn mappings & Loader**: https://fabricmc.net/develop/
- **Fabric API**: https://modrinth.com/mod/fabric-api

## Notes on the Mixin

`DebugHudMixin` targets `net.minecraft.client.gui.hud.DebugHud#getLeftText`.  
If Yarn renames this method in a future build, update the `method` string in the `@Inject` annotation.
