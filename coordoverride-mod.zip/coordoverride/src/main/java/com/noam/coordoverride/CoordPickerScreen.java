package com.noam.coordoverride;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.screen.ScreenTexts;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

public class CoordPickerScreen extends Screen {

    private final Screen parent;

    // Mode buttons
    private final List<ButtonWidget> modeButtons = new ArrayList<>();

    // Custom coord fields (only shown when CUSTOM mode is selected)
    private TextFieldWidget fieldX;
    private TextFieldWidget fieldY;
    private TextFieldWidget fieldZ;

    // Current staged selection (not saved until "Save" is pressed)
    private CoordConfig.CoordMode stagedMode;

    // Feedback label after saving
    private int savedTick = 0;

    public CoordPickerScreen(Screen parent) {
        super(Text.translatable("coordoverride.gui.title"));
        this.parent = parent;
        this.stagedMode = CoordConfig.getMode();
    }

    @Override
    protected void init() {
        int centerX = this.width / 2;
        int startY = 50;
        int btnWidth = 200;
        int btnHeight = 20;
        int gap = 24;

        CoordConfig.CoordMode[] modes = CoordConfig.CoordMode.values();
        for (int i = 0; i < modes.length; i++) {
            final CoordConfig.CoordMode m = modes[i];
            int y = startY + i * gap;

            ButtonWidget btn = ButtonWidget.builder(
                    Text.literal(m.displayName),
                    b -> selectMode(m)
            ).dimensions(centerX - btnWidth / 2, y, btnWidth, btnHeight).build();

            modeButtons.add(btn);
            this.addDrawableChild(btn);
        }

        // Custom coordinate text fields
        int fieldsY = startY + modes.length * gap + 10;
        int fieldWidth = 60;
        int labelOffset = 45;

        fieldX = new TextFieldWidget(this.textRenderer,
                centerX - labelOffset - fieldWidth, fieldsY,
                fieldWidth, 20, Text.literal("X"));
        fieldX.setText(String.valueOf(CoordConfig.getCustomX()));
        fieldX.setMaxLength(16);
        this.addDrawableChild(fieldX);

        fieldY = new TextFieldWidget(this.textRenderer,
                centerX - fieldWidth / 2, fieldsY,
                fieldWidth, 20, Text.literal("Y"));
        fieldY.setText(String.valueOf(CoordConfig.getCustomY()));
        fieldY.setMaxLength(16);
        this.addDrawableChild(fieldY);

        fieldZ = new TextFieldWidget(this.textRenderer,
                centerX + labelOffset, fieldsY,
                fieldWidth, 20, Text.literal("Z"));
        fieldZ.setText(String.valueOf(CoordConfig.getCustomZ()));
        fieldZ.setMaxLength(16);
        this.addDrawableChild(fieldZ);

        // Save / Cancel buttons
        int bottomY = fieldsY + 35;
        this.addDrawableChild(ButtonWidget.builder(
                Text.translatable("coordoverride.gui.save"),
                b -> save()
        ).dimensions(centerX - 105, bottomY, 100, 20).build());

        this.addDrawableChild(ButtonWidget.builder(
                ScreenTexts.CANCEL,
                b -> this.close()
        ).dimensions(centerX + 5, bottomY, 100, 20).build());

        refreshButtonHighlights();
    }

    /** Visually mark the active mode button */
    private void refreshButtonHighlights() {
        CoordConfig.CoordMode[] modes = CoordConfig.CoordMode.values();
        for (int i = 0; i < modes.length; i++) {
            boolean active = modes[i] == stagedMode;
            // Prefix active mode with "> "
            modeButtons.get(i).setMessage(
                    Text.literal(active ? "§a▶ " : "    ").append(modes[i].displayName)
            );
        }

        // Enable/disable custom fields based on mode
        boolean customMode = stagedMode == CoordConfig.CoordMode.CUSTOM;
        fieldX.setEditable(customMode);
        fieldY.setEditable(customMode);
        fieldZ.setEditable(customMode);
        fieldX.setFocused(false);
        fieldY.setFocused(false);
        fieldZ.setFocused(false);
    }

    private void selectMode(CoordConfig.CoordMode mode) {
        stagedMode = mode;
        refreshButtonHighlights();
    }

    private void save() {
        CoordConfig.setMode(stagedMode);

        if (stagedMode == CoordConfig.CoordMode.CUSTOM) {
            try { CoordConfig.setCustomX(Double.parseDouble(fieldX.getText())); } catch (NumberFormatException ignored) {}
            try { CoordConfig.setCustomY(Double.parseDouble(fieldY.getText())); } catch (NumberFormatException ignored) {}
            try { CoordConfig.setCustomZ(Double.parseDouble(fieldZ.getText())); } catch (NumberFormatException ignored) {}
        }

        CoordConfig.save();
        savedTick = 60; // show "Saved!" for ~3 seconds (20 ticks/s)
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        // Dark background
        this.renderBackground(context, mouseX, mouseY, delta);

        // Title
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                this.title,
                this.width / 2, 18, 0xFFFFFF
        );

        // Section label
        context.drawCenteredTextWithShadow(
                this.textRenderer,
                Text.translatable("coordoverride.gui.mode"),
                this.width / 2, 38, 0xAAAAAA
        );

        // Custom field labels
        int centerX = this.width / 2;
        int fieldsLabelY = fieldX.getY() - 12;
        context.drawTextWithShadow(this.textRenderer, "X", fieldX.getX() + 2, fieldsLabelY, 0xFF5555);
        context.drawTextWithShadow(this.textRenderer, "Y", fieldY.getX() + 2, fieldsLabelY, 0x55FF55);
        context.drawTextWithShadow(this.textRenderer, "Z", fieldZ.getX() + 2, fieldsLabelY, 0x5555FF);

        // Dim custom fields if not in CUSTOM mode
        if (stagedMode != CoordConfig.CoordMode.CUSTOM) {
            context.fill(fieldX.getX() - 1, fieldX.getY() - 1,
                    fieldZ.getX() + fieldZ.getWidth() + 1, fieldZ.getY() + fieldZ.getHeight() + 1,
                    0x88000000);
        }

        // "Saved!" feedback
        if (savedTick > 0) {
            savedTick--;
            int alpha = Math.min(255, savedTick * 8);
            context.drawCenteredTextWithShadow(
                    this.textRenderer,
                    Text.translatable("coordoverride.gui.saved"),
                    centerX, fieldX.getY() + 30, (alpha << 24) | 0x55FF55
            );
        }

        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false; // don't pause the game
    }

    @Override
    public void close() {
        if (this.client != null) this.client.setScreen(parent);
    }
}
