package com.noam.coordoverride;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.*;
import java.nio.file.Path;

public class CoordConfig {

    public enum CoordMode {
        REAL("Real XYZ"),
        BLOCK("Block XYZ"),
        CHUNK("Chunk Coords"),
        CUSTOM("Custom Coords"),
        HIDDEN("Hide Coordinates");

        public final String displayName;
        CoordMode(String name) { this.displayName = name; }
    }

    // --- State ---
    private static CoordMode mode = CoordMode.REAL;
    private static double customX = 0.0;
    private static double customY = 64.0;
    private static double customZ = 0.0;

    // --- Getters ---
    public static CoordMode getMode() { return mode; }
    public static double getCustomX() { return customX; }
    public static double getCustomY() { return customY; }
    public static double getCustomZ() { return customZ; }

    // --- Setters ---
    public static void setMode(CoordMode m) { mode = m; }
    public static void setCustomX(double v) { customX = v; }
    public static void setCustomY(double v) { customY = v; }
    public static void setCustomZ(double v) { customZ = v; }

    // --- Persistence ---
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private static Path configPath() {
        return FabricLoader.getInstance().getConfigDir().resolve("coordoverride.json");
    }

    public static void save() {
        ConfigData data = new ConfigData();
        data.mode = mode.name();
        data.customX = customX;
        data.customY = customY;
        data.customZ = customZ;
        try (Writer w = new FileWriter(configPath().toFile())) {
            GSON.toJson(data, w);
        } catch (IOException e) {
            CoordOverrideMod.LOGGER.error("Failed to save config", e);
        }
    }

    public static void load() {
        File f = configPath().toFile();
        if (!f.exists()) return;
        try (Reader r = new FileReader(f)) {
            ConfigData data = GSON.fromJson(r, ConfigData.class);
            if (data == null) return;
            if (data.mode != null) {
                try { mode = CoordMode.valueOf(data.mode); } catch (Exception ignored) {}
            }
            customX = data.customX;
            customY = data.customY;
            customZ = data.customZ;
        } catch (IOException e) {
            CoordOverrideMod.LOGGER.error("Failed to load config", e);
        }
    }

    private static class ConfigData {
        String mode;
        double customX;
        double customY;
        double customZ;
    }
}
