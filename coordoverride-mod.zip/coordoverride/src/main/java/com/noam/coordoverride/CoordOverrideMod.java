package com.noam.coordoverride;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class CoordOverrideMod implements ClientModInitializer {

    public static final String MOD_ID = "coordoverride";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    // The keybind the player can configure in Controls settings
    public static KeyBinding openPickerKey;

    @Override
    public void onInitializeClient() {
        // Load saved config
        CoordConfig.load();

        // Register the keybind (default: G)
        openPickerKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.coordoverride.open_picker",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_G,
                "CoordOverride"
        ));

        // Listen every client tick to detect keypress
        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openPickerKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new CoordPickerScreen(client.currentScreen));
                }
            }
        });

        LOGGER.info("CoordOverride loaded. Press {} to open the coord picker.",
                openPickerKey.getBoundKeyLocalizedText().getString());
    }
}
