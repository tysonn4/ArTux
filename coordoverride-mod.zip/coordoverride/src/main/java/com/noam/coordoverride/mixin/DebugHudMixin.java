package com.noam.coordoverride.mixin;

import com.noam.coordoverride.CoordConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.hud.DebugHud;
import net.minecraft.entity.Entity;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.ChunkPos;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

import java.util.ArrayList;
import java.util.List;

@Mixin(DebugHud.class)
public class DebugHudMixin {

    /**
     * Intercept the list returned by getLeftText() and replace the XYZ line
     * with whichever mode the player has chosen in the Coord Picker.
     *
     * The vanilla XYZ line looks like:
     *   "XYZ: 123.456 / 64.000 / -78.901"
     * We find it by the "XYZ:" prefix and replace (or remove) it in-place.
     */
    @Inject(method = "getLeftText", at = @At("RETURN"), cancellable = true)
    private void onGetLeftText(CallbackInfoReturnable<List<String>> cir) {
        CoordConfig.CoordMode mode = CoordConfig.getMode();

        // Nothing to do for default real coords
        if (mode == CoordConfig.CoordMode.REAL) return;

        List<String> original = cir.getReturnValue();
        List<String> modified = new ArrayList<>(original);

        // Locate the XYZ line index
        int xyzIndex = -1;
        for (int i = 0; i < modified.size(); i++) {
            if (modified.get(i).startsWith("XYZ:")) {
                xyzIndex = i;
                break;
            }
        }
        if (xyzIndex == -1) return; // Couldn't find it — bail out safely

        switch (mode) {
            case HIDDEN -> {
                // Remove the XYZ line and also the Block/Chunk lines that follow it
                // (vanilla adds "Block: …" and "Chunk: …" right after XYZ)
                modified.remove(xyzIndex); // XYZ
                if (xyzIndex < modified.size() && modified.get(xyzIndex).startsWith("Block:"))
                    modified.remove(xyzIndex);
                if (xyzIndex < modified.size() && modified.get(xyzIndex).startsWith("Chunk:"))
                    modified.remove(xyzIndex);
            }

            case BLOCK -> {
                MinecraftClient client = MinecraftClient.getInstance();
                Entity cam = client.getCameraEntity();
                if (cam == null) return;
                BlockPos pos = cam.getBlockPos();
                modified.set(xyzIndex,
                        String.format("XYZ: %d / %d / %d  §7(Block)", pos.getX(), pos.getY(), pos.getZ()));
            }

            case CHUNK -> {
                MinecraftClient client = MinecraftClient.getInstance();
                Entity cam = client.getCameraEntity();
                if (cam == null) return;
                BlockPos pos = cam.getBlockPos();
                ChunkPos chunkPos = new ChunkPos(pos);
                int localX = pos.getX() & 15;
                int localY = pos.getY() & 15;
                int localZ = pos.getZ() & 15;
                modified.set(xyzIndex,
                        String.format("XYZ: Chunk [%d, %d]  §7Local: %d/%d/%d",
                                chunkPos.x, chunkPos.z, localX, localY, localZ));
            }

            case CUSTOM -> {
                double cx = CoordConfig.getCustomX();
                double cy = CoordConfig.getCustomY();
                double cz = CoordConfig.getCustomZ();
                modified.set(xyzIndex,
                        String.format("XYZ: %.3f / %.3f / %.3f  §7(custom)", cx, cy, cz));
            }

            default -> { /* REAL — handled above */ }
        }

        cir.setReturnValue(modified);
    }
}
